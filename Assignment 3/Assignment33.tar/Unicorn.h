#ifndef Unicorn_H
#define Unicorn_H
#include "Animal.h"
class Unicorn : public Animal
{
public:
    Unicorn();
    ~Unicorn();
    Unicorn &operator=(const Unicorn &x);
};
#endif
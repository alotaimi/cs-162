#include <iostream>
#include "Wumpus.h"
using namespace std;

Wumpus::Wumpus(){
    Who = "Wumpus";
    Message = "You smell a terrible stench.";
}
Wumpus::~Wumpus(){}

void Wumpus::action(){
    cout << "Game Over"<<endl;
    cout << "You have been eaten by Wumpus"<<endl;
}
Wumpus &Wumpus::operator=(const Wumpus &old_obj){
    this->Who = old_obj.Who;
    this->Message = old_obj.Message;
    return *this;
}
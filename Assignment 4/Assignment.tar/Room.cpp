#include <iostream>
#include "Room.h"
using namespace std;

Room::Room(){
    has_event = false;
    event = NULL;
}
Room::~Room(){
    event = NULL;
    delete event;
}
void Room::setevent(Event* x){
    if(event != NULL){
        event = NULL;
    }
    event = x;
    message = event->getMessage();
     Who = event->getWho();
     if(Who == "Player"){
     has_event = false;
     }
     else{
         has_event = true;
     }
}
void Room::sethas(bool x){
    has_event = x;
}
Event* Room::getevent(){
    return event;
}
string Room::getWho(){
    return Who;
}
string Room::getmessage(){
    return message;
}
bool Room::gethas(){
    return has_event;
}
void Room::action(){
    event->action();
}
Room &Room::operator=(const Room &old_obj){
    this->event = old_obj.event;
    this->has_event = old_obj.has_event;
    return *this;
}

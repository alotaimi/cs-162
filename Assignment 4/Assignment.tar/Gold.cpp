#include <iostream>
#include "Gold.h"
using namespace std;

Gold::Gold(){
    Who = "Gold";
    Message = "You see a glimmer nearby.";
}
Gold::~Gold(){}

void Gold::action(){
    cout << "You have obtained The treasure"<<endl;
}
Gold &Gold::operator=(const Gold &old_obj){
    this->Who = old_obj.Who;
    this->Message = old_obj.Message;
    return *this;
}
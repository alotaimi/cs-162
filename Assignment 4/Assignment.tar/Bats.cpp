#include <iostream>
#include "Bats.h"
using namespace std;

Bats::Bats(){
    Who = "Bats";
    Message = "You hear wings flapping.";
}
Bats::~Bats(){}

void Bats::action(){
    cout << "Bats took you to another room"<<endl;
}
Bats &Bats::operator=(const Bats &old_obj){
    this->Who = old_obj.Who;
    this->Message = old_obj.Message;
    return *this;
}
#include <iostream>
#include "Player.h"
using namespace std;

Player::Player(){
    Who = "Player";
    Message = "Nothing";
}
Player::~Player(){}

void Player::action(){
}
Player &Player::operator=(const Player &old_obj){
    this->Who = old_obj.Who;
    this->Message = old_obj.Message;
    return *this;
}
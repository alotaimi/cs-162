#ifndef PLAYER_H
#define PLAYER_H
#include "Event.h"
class Player : public Event{
    public:
    Player();
    ~Player();
    void action();
    Player &operator=(const Player &old_obj);
};
#endif
#include <iostream>
#include "Escape.h"
using namespace std;

Escape::Escape(){
    Who = "Escape";
    Message = "";
}
Escape::~Escape(){}

void Escape::action(){
    cout << "you have won"<<endl;
    cout << "You have escaped the cave"<<endl;
}
Escape &Escape::operator=(const Escape &old_obj){
    this->Who = old_obj.Who;
    this->Message = old_obj.Message;
    return *this;
}
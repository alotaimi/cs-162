#include <iostream>
#include "Pit.h"
using namespace std;

Pit::Pit(){
    Who = "Pit";
    Message = "You feel a breeze.";
}
Pit::~Pit(){}

void Pit::action(){
    cout << "Game Over"<<endl;
    cout << "You have fallen down and got killed"<<endl;
}
Pit &Pit::operator=(const Pit &old_obj){
    this->Who = old_obj.Who;
    this->Message = old_obj.Message;
    return *this;
}
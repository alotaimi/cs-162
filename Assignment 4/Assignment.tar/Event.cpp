#include <iostream>
#include "Event.h"
using namespace std;
Event::Event(){
    Who = "Nothing";
    Message = "No Action";
}
Event::~Event(){
}
void Event::setWho(string x){
    Who = x;
}
void Event::setMessage(string x){
    Message = x;
}
string Event::getWho(){
    return Who;
}
string Event::getMessage(){
    return Message;
}
void Event::action(){}
Event &Event::operator=(const Event &old_obj){
    this->Who = old_obj.Who;
    this->Message = old_obj.Message;
    return *this;
}
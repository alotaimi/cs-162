#include <iostream>
#include <iostream>
#include <fstream>
#include "restaurant.h"
#include "menu.h"
#include "emp_hours.h"

using namespace std;

int main(int argc, char *argv[])
{
	Restaurant restaurant;
	restaurant.create();
	restaurant.load_data();
	//program starts here
	cout << "Welcome to Bytes Pizza!" << endl;
	char user;
	int id;
	int choice;
	int choicesHours;
	string password;
	int loop = 0;
	int loop2 = 0;
	int loop3 = 0;
	cout << "Are you a customer (C) or employee (E) or would you like to quit (Q)?" << endl;
	while (loop == 0)
	{
		cin >> user;
		if (user == 'E' || user == 'e')
		{
			cout << "Please provide an id" << endl;
			cin >> id;
			cout << "Please provide a Password" << endl;
			cin >> password;
			if (restaurant.login(id, password))
			{
				while (loop == 0)
				{
					cout << "What would you like to do?"
						 << "\t"
						 << " 1. Change hours"
						 << "\t"
						 << " 2. View orders"
						 << "\t"
						 << " 3. Remove order"
						 << "\t "
						 << " 4. Add Item to Menu"
						 << "\t "
						 << " 5. Remove Item from Menu "
						 << "\t "
						 << " 6. View Menu "
						 << "\t "
						 << " 7. View Hours "
						 << "\t "
						 << " 8. View Address "
						 << "\t "
						 << " 9. View Phone "
						 << "\t "
						 << " 10. View Name "
						 << "\t"
						 << "11. log out" << endl;
					cin >> choice;
					if (choice == 1)
					{
						cout << "What option would you like to do?"
							 << "\t"
							 << "1. add hours"
							 << "\t"
							 << "2. Change hours" << endl;
						cin >> choicesHours;
						if (choicesHours == 1)
						{
							restaurant.add_hours();
							restaurant.view_hours();
							restaurant.Updatedlist();
						}
						else if (choicesHours == 2)
						{
							restaurant.change_hours();
							restaurant.view_hours();
							restaurant.Updatedlist();
						}
					}
					else if (choice == 2)
					{
					}
					else if (choice == 3)
					{
					}
					else if (choice == 4)
					{
					}
					else if (choice == 5)
					{
					}
					else if (choice == 6)
					{
					}
					else if (choice == 7)
					{
						restaurant.view_hours();
					}
					else if (choice == 8)
					{
						restaurant.view_address();
					}
					else if (choice == 9)
					{
						restaurant.view_phone();
					}
					else if (choice == 10)
					{
						restaurant.view_name();
					}
					else if (choice == 11)
					{
						cout << "Are you a customer (C) or employee (E) or would you like to quit (Q)?" << endl;
						break;
					}
					else
					{
						cout << "Wrong choice" << endl;
					}
				}
			}
			else
			{
				cout << "Are you a customer (C) or employee (E) or would you like to quit (Q)?" << endl;
			}
		}
		else if (user == 'C' || user == 'c')
		{
		}
		else if (user == 'Q' || user == 'q')
		{
			return 0;
		}
		else
		{
			cout << "Wrong input" << endl;
		}
	}
	return 0;
}
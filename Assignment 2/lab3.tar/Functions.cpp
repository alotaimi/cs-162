#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include "restaurant.h"

int Restaurant::count_line(string x)
{
  string line;
  int counter = 0;
  ifstream fin;
  fin.open(x.c_str());
  while (!fin.eof())
  {
    getline(fin, line);
    counter++;
  }
  fin.close();
  return counter - 1;
}

Restaurant::Restaurant()
{
  employees = NULL;
  week = NULL;
  name = " ";
  phone = " ";
  address = " ";
}
Restaurant::~Restaurant()
{
  delete[] week;
  delete[] employees;
}
void Restaurant::createEmp()
{
  int num_employees = count_line("employee.txt");
  setnumEmp(num_employees);
  employees = new employee[this->num_Emp];
}
void Restaurant::load_dataEmp()
{
  ifstream employee_file;
  employee_file.open("employee.txt");
  int num_employee = count_line("employee.txt");

  for (int i = 0; i < this->num_Emp; i++)
  {
    employee_file >> employees[i].id >> employees[i].password >> employees[i].first_name >> employees[i].last_name;
  }
  employee_file.close();
}
void Restaurant::createHours()
{
  int num_hours = count_line("restaurant_info.txt");
  num_hours = num_hours - 3;
  sethours(num_hours);
  week = new hours[this->num_hours];
}
void Restaurant::load_dataHours()
{
  ifstream restaurant_file;
  restaurant_file.open("restaurant_info.txt");
  string line1, line2, line3, name, phone, address;
  getline(restaurant_file, name);
  getline(restaurant_file, phone);
  getline(restaurant_file, address);
  setaddress(address);
  setname(name);
  setphone(phone);
  for (int i = 0; i < this->num_hours; i++)
  {
    restaurant_file >> line1 >> line2 >> line3;
    week[i].day = line1;
    week[i].open_hour = line2;
    week[i].close_hour = line3;
  }
}
void Restaurant::create()
{
  createEmp();
  createHours();
}
void Restaurant::load_data()
{
  load_dataEmp();
  load_dataHours();
}
void Restaurant::view_hours()
{
  cout << "The Updated Hours:" << endl;
  for (int i = 0; i < this->num_hours; i++)
  {
    cout << week[i].day << " " << week[i].open_hour << " " << week[i].close_hour << endl;
  }
}
void Restaurant::add_hours()
{
  string day, open, close;
  cout << "Whhich day?" << endl;
  cin >> day;
  cout << "Which open hour?" << endl;
  cin >> open;
  cout << "which closing hour?" << endl;
  cin >> close;
  hours *week_temp = new hours[this->num_hours + 1];
  for (int i = 0; i < this->num_hours; i++)
  {
    week_temp[i] = this->week[i];
  }
  week_temp[this->num_hours].day = day;
  week_temp[this->num_hours].open_hour = open;
  week_temp[this->num_hours].close_hour = close;
  if (this->week != NULL)
  {
    delete[] this->week;
  }
  this->week = week_temp;
  this->num_hours++;
}
void Restaurant::change_hours()
{
  string day, open, close;
  cout << "Which day would you like to change the hours?" << endl;
  cin >> day;
  for (int i = 0; i < this->num_hours; i++)
  {
    if (day == week[i].day)
    {
      cout << "When do you want the openning hours?" << endl;
      cin >> open;
      cout << "When do you want the closing hours?" << endl;
      cin >> close;
      week[i].open_hour = open;
      week[i].close_hour = close;
    }
  }
}
bool Restaurant::login(int id, string password)
{
  for (int i = 0; i < this->num_Emp; i++)
  {
    if (employees[i].id == id)
    {
      if (this->employees[i].password == password)
      {
        cout << "Welcome:" << employees[i].first_name << " " << employees[i].last_name << endl;
        return true;
      }
      else
      {
        return false;
      }
    }
    else
    {
      return false;
    }
  }
}
void Restaurant::setaddress(string x)
{
  this->address = x;
}
void Restaurant::setphone(string z)
{
  this->phone = z;
}
void Restaurant::setname(string z)
{
  this->name = z;
}
void Restaurant::view_address()
{
  cout << "Our address is: " << this->address << endl;
}
void Restaurant::view_phone()
{
  cout << "You can contact us by phone: " << this->phone << endl;
}
void Restaurant::view_name()
{
  cout << "The name of tthe restaurant is: " << this->name << endl;
}
void Restaurant::sethours(int x)
{
  this->num_hours = x;
}
void Restaurant::setnumEmp(int x)
{
  this->num_Emp = x;
}
void Restaurant::Updatedlist()
{
  ofstream saveHours;
  saveHours.open("restaurant_info.txt");
  saveHours << this->name << endl;
  saveHours << this->phone << endl;
  saveHours << this->address << endl;
  for (int i = 0; i < this->num_hours; i++)
  {
    saveHours << week[i].day << " " << week[i].open_hour << " " << week[i].close_hour << endl;
  }
}